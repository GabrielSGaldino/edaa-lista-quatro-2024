# edaa-lista-quatro-2024

### Grupo:
- Cesar Martins
- Gabriel Galdino
- Lucas Marques da Silva

